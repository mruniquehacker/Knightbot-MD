module.exports = async function githubCommand(sock, chatId, message) {
  await sock.sendMessage(chatId, { text: '❌ The GitHub command has been removed by the owner.' }, { quoted: message });
}; 